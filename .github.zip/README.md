# SSH Monitor UI

Web app to monitor multiple systems over SSH and collect PMUtil and Turbostat data on a timed schedule.

## Features
- Dynamic system count input (numeric up/down)
- Global idle time and monitor duration controls
- Per-system setup: system name, IP, SSH credentials, PMUtil command/path, Turbostat command/path
- Per-system Monitor and Stop controls
- Per-system live output page (opens in a new window)
- Active-only summary table in main UI:
  - System name, IP, sockets (from PMUtil), C6 and PC6 (from Turbostat), elapsed, time left
- Log path shown on each system card when run stops/completes/errors
- Logs saved as text files under `logs/`

## Stack
- Node.js + Express backend
- WebSocket live updates
- Vanilla HTML/CSS/JavaScript frontend
- SSH execution via `ssh2`

## Setup
1. Install dependencies:
   ```powershell
   npm install
   ```
2. Start in development mode:
   ```powershell
   npm run dev
   ```
3. Open:
   ```
   http://localhost:3000
   ```

## Configuration Notes
- Default PMUtil command used when field is empty:
   - `cd /root/apps/PI_PM/pmutil && ./pmutil_bin -i`
- Default Turbostat command used when field is empty:
   - `cd /root/apps/PI_PM/turbostat && ./turbostat -q -s Package,Node,Core,CPU,Bzy_MHz,IPC,Busy%,CPU%c1,CPU%c6,C1E%,CoreTmp,PkgTmp,Pkg%pc2,Pkg%pc6,PkgWatt,RAMWatt,UncMHz,Mod%c6 -interval 1 -n 5`
- Current backend uses password authentication for SSH.
- Idle time controls data collection interval.
- Monitor duration controls total run time per system.

## API Endpoints
- `GET /health`
- `GET /api/systems`
- `GET /api/systems/active`
- `POST /api/systems`
- `POST /api/systems/:id/start`
- `POST /api/systems/:id/stop`
- `GET /api/systems/:id/details`
- `GET /api/systems/:id/log`
